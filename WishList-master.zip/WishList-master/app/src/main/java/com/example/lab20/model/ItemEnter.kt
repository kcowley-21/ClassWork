package com.example.lab20.model

data class ItemEnter (
    val userName:String,
    val userChoice:String
)